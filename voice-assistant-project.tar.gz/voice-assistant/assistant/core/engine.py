from __future__ import annotations
import logging
import os
import uuid
from typing import Any, Dict, Optional

from .config import load_config, data_path
from .context import DialogContext
from .storage import Storage
from ..nlu.router import IntentRouter
from ..skills.base import SkillRegistry
from ..skills.smalltalk import SmalltalkSkill
from ..skills.time_skill import TimeSkill
from ..skills.calc_skill import CalcSkill
from ..skills.notes_skill import NotesSkill
from ..skills.timer_skill import TimerSkill
from ..skills.help_skill import HelpSkill
from ..skills.system_skill import SystemSkill
from ..skills.search_skill import SearchSkill
from ..skills.weather_skill import WeatherSkill
from ..skills.homelab_skill import HomelabSkill
from ..skills.ha_skill import HomeAssistantSkill
from ..skills.web_skill import WebSkill
from ..skills.app_skill import AppControlSkill
from ..skills.fallback_skill import FallbackSkill
from ..tts.base import get_tts_provider
from ..stt.base import get_stt_provider
from ..integrations.homeassistant import ha_client_from_config

log = logging.getLogger("assistant")


def setup_logging(cfg: Dict[str, Any]):
    level_name = str(cfg.get('app', {}).get('log_level', 'INFO')).upper()
    level = getattr(logging, level_name, logging.INFO)
    root = logging.getLogger()
    if not root.handlers:
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        )
    else:
        root.setLevel(level)
    logging.getLogger("assistant").setLevel(level)


class AssistantEngine:
    VERSION = "0.2.0"

    def __init__(self, config_path: Optional[str] = None):
        self.cfg = load_config(config_path)
        setup_logging(self.cfg)
        self.storage = Storage(data_path(self.cfg, 'assistant.db'))
        self.router = IntentRouter()
        self.registry = SkillRegistry()
        self.tts = get_tts_provider(self.cfg)
        self.stt = get_stt_provider(self.cfg)
        self.ha = ha_client_from_config(self.cfg)
        self._sessions: Dict[str, DialogContext] = {}
        self._register_skills()

    def _register_skills(self):
        cfg, st = self.cfg, self.storage
        enabled = set(self.cfg.get('skills', {}).get('enabled', []))
        def want(name):
            return not enabled or name in enabled or name in ('smalltalk', 'help', 'fallback')
        # inject HA client into skills via cfg reference convenience
        for skill in [
            SmalltalkSkill(cfg, st), TimeSkill(cfg, st), CalcSkill(cfg, st),
            NotesSkill(cfg, st), TimerSkill(cfg, st), HelpSkill(cfg, st),
            SystemSkill(cfg, st), SearchSkill(cfg, st), WeatherSkill(cfg, st),
            HomeAssistantSkill(cfg, st), HomelabSkill(cfg, st),
            WebSkill(cfg, st), AppControlSkill(cfg, st), FallbackSkill(cfg, st),
        ]:
            if hasattr(skill, 'ha'):
                try:
                    skill.ha = self.ha  # type: ignore[attr-defined]
                except Exception:
                    pass
            if want(skill.name):
                self.registry.register(skill)

    def get_context(self, session_id: str = "default") -> DialogContext:
        if session_id not in self._sessions:
            lang = self.cfg.get('app', {}).get('language', 'ru')
            self._sessions[session_id] = DialogContext(session_id=session_id, language=lang)
        return self._sessions[session_id]

    def rooms(self):
        rooms = self.cfg.get('rooms') or []
        if not isinstance(rooms, list):
            return []
        return rooms

    def resolve_room(self, room_hint: Optional[str], ctx: DialogContext) -> Dict[str, Any]:
        rooms = self.rooms()
        default_room = rooms[0] if rooms else {"id": "default", "name": "Дом", "aliases": []}
        hint = (room_hint or ctx.slots.get('room') or ctx.slots.get('room_id') or '').strip().lower()
        if not hint:
            return default_room
        for r in rooms:
            rid = str(r.get('id', '')).lower()
            name = str(r.get('name', '')).lower()
            aliases = [str(a).lower() for a in (r.get('aliases') or [])]
            if hint in {rid, name} or hint in aliases:
                return r
            # contains match for common phrases
            if name and (name in hint or hint in name):
                return r
        # remember raw hint
        return {**default_room, "_hint": room_hint}

    def process(self, text: str, session_id: str = "default", meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        meta = dict(meta or {})
        ctx = self.get_context(session_id)
        text = (text or '').strip()
        room = self.resolve_room(meta.get('room') or meta.get('room_id'), ctx)
        if room and room.get('id'):
            ctx.slots['room'] = room.get('id')
            ctx.slots['room_name'] = room.get('name')
            meta['room'] = room.get('id')
            meta['room_name'] = room.get('name')

        ctx.add('user', text, **meta)
        if self.cfg.get('security', {}).get('log_conversations'):
            self.storage.add_history('user', text, meta)

        fired = self.storage.fire_due_timers()
        notices = []
        for t in fired:
            notices.append(f"⏰ Сработал таймер: {t.get('label') or t.get('id')}")

        intent = self.router.route(text)
        # enrich intent with room hints from entities/meta
        if meta.get('room'):
            intent.entities.setdefault('room', meta.get('room'))
            intent.entities.setdefault('room_name', meta.get('room_name'))
        intent.entities.setdefault('session_id', session_id)

        resp = self.registry.dispatch(intent, ctx)
        if resp is None:
            resp = self.registry.get('fallback').handle(intent, ctx) if self.registry.get('fallback') else None
        if resp is None:
            from ..nlu.intents import SkillResponse
            resp = SkillResponse(text="Не удалось обработать запрос.")

        if notices:
            resp.text = "\n".join(notices) + "\n\n" + resp.text

        speak_text = resp.speak or resp.text
        ctx.add('assistant', resp.text, intent=intent.intent, skill=getattr(intent, 'skill', None))
        ctx.last_intent = intent.intent
        if self.cfg.get('security', {}).get('log_conversations'):
            self.storage.add_history('assistant', resp.text, {"intent": intent.intent, "room": meta.get('room')})

        return {
            "text": resp.text,
            "speak": speak_text,
            "intent": intent.intent,
            "skill": intent.skill,
            "confidence": intent.confidence,
            "entities": intent.entities,
            "data": resp.data,
            "session_id": session_id,
            "room": {"id": room.get('id'), "name": room.get('name')} if room else None,
        }

    def status(self, quick: bool = True) -> Dict[str, Any]:
        ha_status = None
        try:
            ha_status = self.ha.safe_status(quick=quick)
        except Exception:
            ha_status = {"configured": False, "reachable": False}
        return {
            "name": self.cfg.get('app', {}).get('name'),
            "version": self.VERSION,
            "language": self.cfg.get('app', {}).get('language'),
            "tts": self.tts.name,
            "stt": self.stt.name,
            "llm_provider": self.cfg.get('llm', {}).get('provider'),
            "llm_configured": bool((self.cfg.get('llm', {}).get('openai_compat') or {}).get('base_url')),
            "skills": sorted(self.registry.by_name.keys()),
            "home_assistant": ha_status,
            "rooms": [{"id": r.get("id"), "name": r.get("name")} for r in self.rooms()],
        }
