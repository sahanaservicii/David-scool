from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from .base import Skill
from ..nlu.intents import IntentResult, SkillResponse
from ..core.context import DialogContext
from ..integrations.homeassistant import HomeAssistantClient, ha_client_from_config


ON_WORDS = ("включи", "вруби", "зажги", "активируй", "запусти", "turn on", "enable")
OFF_WORDS = ("выключи", "отключи", "погаси", "деактивируй", "останови", "turn off", "disable", "stop")
TOGGLE_WORDS = ("переключи", "toggle",)

LIGHT_DOMAINS = ["light", "switch", "input_boolean"]
MEDIA_DOMAINS = ["media_player"]
CLIMATE_DOMAINS = ["climate"]
COVER_DOMAINS = ["cover"]
SCENE_SCRIPT_DOMAINS = ["scene", "script", "automation"]


def _contains_any(text: str, words) -> bool:
    t = (text or "").lower()
    return any(w in t for w in words)


def _extract_room(text: str, rooms: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    t = (text or "").lower()
    # explicit "в ..." / "in ..."
    for r in rooms:
        names = [str(r.get("id", "")), str(r.get("name", ""))] + [str(a) for a in (r.get("aliases") or [])]
        for n in names:
            n = n.strip().lower()
            if not n:
                continue
            # match as word-ish
            if re.search(rf"(^|\b|\s){re.escape(n)}(\b|\s|$)", t):
                return r
    return None


def _entity_name_guess(text: str) -> str:
    t = (text or "").lower()
    # remove common command words
    patterns = [
        r"^(пожалуйста\s+)?(включи|выключи|вруби|отключи|зажги|погаси|переключи|сделай|поставь|установи|запусти|останови|пауза|продолжи|следующ|предыдущ|громче|тише)\s+",
        r"\b(в этой комнате|в комнате|здесь|тут)\b",
        r"\b(свет|ламп[уаы]|музык[уаыеи]|песн[юяи]|трек|радио|телевизор|тв)\b",
        r"\b(на|в|у)\s*$",
    ]
    for p in patterns:
        t = re.sub(p, " ", t)
    t = re.sub(r"\s+", " ", t).strip(" ,.-")
    return t


class HomeAssistantSkill(Skill):
    name = "ha"
    description = "Управление и статус Home Assistant (умный дом, мультирум-медиа)"
    intents = [
        "ha_status", "ha_control", "ha_query", "media_control",
        "ha_turn_on", "ha_turn_off", "ha_toggle",
    ]

    def __init__(self, cfg: Dict[str, Any], storage):
        super().__init__(cfg, storage)
        try:
            self.ha = ha_client_from_config(cfg)
        except Exception:
            self.ha = HomeAssistantClient("", "")

    def _rooms(self) -> List[Dict[str, Any]]:
        rooms = self.cfg.get("rooms") or []
        return rooms if isinstance(rooms, list) else []

    def _current_room(self, intent: IntentResult, ctx: DialogContext) -> Dict[str, Any]:
        rooms = self._rooms()
        # from entities/meta
        hint = intent.entities.get("room") or intent.entities.get("room_name") or ctx.slots.get("room")
        if hint:
            h = str(hint).lower()
            for r in rooms:
                if h in {str(r.get("id", "")).lower(), str(r.get("name", "")).lower()}:
                    return r
        found = _extract_room(intent.raw, rooms)
        if found:
            return found
        # fallback to session room
        sid = ctx.slots.get("room")
        if sid:
            for r in rooms:
                if str(r.get("id")) == str(sid):
                    return r
        return rooms[0] if rooms else {"id": "default", "name": "Дом"}

    def _ensure_ha(self) -> Optional[SkillResponse]:
        if not getattr(self.ha, "enabled", False):
            return SkillResponse(text=(
                "Home Assistant не настроен. Укажите `home_assistant.url` и токен (`home_assistant.token` "
                "или `HASS_TOKEN` в secrets/env) в config/config.local.json. "
                "Сейчас статус по homelab недоступен — проверьте доступность HA в сети."
            ), data={"configured": False})
        ping = self.ha.ping()
        if not ping.ok:
            return SkillResponse(text=(
                f"Home Assistant недоступен ({self.ha.base_url}): {ping.error or 'нет ответа'}. "
                "Проверьте, что HA запущен, доступен из этой сети и токен корректен."
            ), data={"configured": True, "reachable": False, "error": ping.error})
        return None

    def handle(self, intent: IntentResult, ctx: DialogContext) -> SkillResponse:
        text = intent.raw or ""
        t = text.lower()

        if intent.intent == "ha_status" or any(w in t for w in ["статус ha", "статус home assistant", "home assistant статус", "умный дом статус", "ha status"]):
            return self._status()

        err = self._ensure_ha()
        if err:
            # for pure status query, still show status attempt
            if intent.intent == "ha_status":
                return self._status()
            return err

        # media controls (priority when media context)
        if intent.intent == "media_control" or any(w in t for w in ["музык", "песн", "трек", "плейлист", "радио", "громк", "тише", "следующ", "предыдущ", "пауза", "продолжи воспроизвед", "spotify", "youtube music", "колонк", "динамик"]):
            return self._handle_media(intent, ctx)

        # on/off/toggle/control/query
        if intent.intent in ("ha_turn_on",) or (_contains_any(t, ON_WORDS) and not _contains_any(t, ["музык", "песн", "трек", "радио"])):
            return self._handle_power(intent, ctx, "turn_on")
        if intent.intent in ("ha_turn_off",) or (_contains_any(t, OFF_WORDS) and not _contains_any(t, ["музык", "песн", "трек", "радио"])):
            return self._handle_power(intent, ctx, "turn_off")
        if intent.intent in ("ha_toggle",) or _contains_any(t, TOGGLE_WORDS):
            return self._handle_power(intent, ctx, "toggle")

        # temperature/sensor/query
        if intent.intent == "ha_query" or any(w in t for w in ["какая температура", "температур", "влажност", "датчик", "состояние", "открыт", "закрыт", "статус устройств", "что включено"]):
            return self._handle_query(intent, ctx)

        # generic control fallback
        if intent.intent == "ha_control" or any(w in t for w in ["свет", "ламп", "штор", "жалюзи", "кондиционер", "климат", "сцен", "скрипт"]):
            if _contains_any(t, OFF_WORDS):
                return self._handle_power(intent, ctx, "turn_off")
            return self._handle_power(intent, ctx, "turn_on")

        return SkillResponse(text="Уточните команду для умного дома: например, «включи свет в кухне», «какая температура в спальне», «пауза музыки в этой комнате».")

    def _status(self) -> SkillResponse:
        if not getattr(self.ha, "enabled", False):
            return SkillResponse(text="Home Assistant не настроен (url/token отсутствуют).", data={"configured": False})
        st = self.ha.safe_status()
        if not st.get("reachable"):
            return SkillResponse(text=f"Home Assistant недоступен: {st.get('url')} ({st.get('error') or 'нет ответа'}).", data=st)
        name = st.get("location_name") or "Home Assistant"
        ver = st.get("version") or "?"
        # quick counts
        counts = ""
        states = self.ha.get_states()
        if states.ok and isinstance(states.data, list):
            total = len(states.data)
            unav = sum(1 for e in states.data if str(e.get("state")) in ("unavailable", "unknown"))
            lights_on = sum(1 for e in states.data if str(e.get("entity_id", "")).startswith("light.") and e.get("state") == "on")
            players = [e for e in states.data if str(e.get("entity_id", "")).startswith("media_player.")]
            playing = sum(1 for e in players if e.get("state") == "playing")
            counts = f"\n• Сущностей: {total}, недоступно: {unav}\n• Свет включён: {lights_on} ламп(ы)\n• Медиа-плееров: {len(players)}, играет: {playing}"
        return SkillResponse(
            text=f"Home Assistant: {name} (v{ver}) доступен по {st.get('url')}.{counts}",
            data=st,
        )

    def _handle_query(self, intent: IntentResult, ctx: DialogContext) -> SkillResponse:
        t = intent.raw.lower()
        room = self._current_room(intent, ctx)
        room_name = str(room.get("name") or room.get("id") or "")
        # temperature
        if "температур" in t or "влажност" in t:
            kind = "temperature" if "температур" in t else "humidity"
            domain_word = "sensor"
            states = self.ha.get_states()
            if not states.ok or not isinstance(states.data, list):
                return SkillResponse(text=f"Не удалось получить состояния из HA: {states.error}")
            candidates = []
            for e in states.data:
                eid = str(e.get("entity_id", ""))
                if not eid.startswith("sensor.") and not eid.startswith("climate."):
                    continue
                attrs = e.get("attributes") or {}
                fname = str(attrs.get("friendly_name") or "")
                dc = str(attrs.get("device_class") or "")
                unit = str(attrs.get("unit_of_measurement") or "")
                hay = (eid + " " + fname + " " + dc).lower()
                if kind == "temperature" and not (dc == "temperature" or "температур" in hay or "°c" in unit.lower() or unit == "°C"):
                    continue
                if kind == "humidity" and not (dc == "humidity" or "влажност" in hay or unit == "%"):
                    continue
                score = 0
                if room_name and room_name.lower() in hay:
                    score += 5
                # room aliases
                for a in (room.get("aliases") or []):
                    if str(a).lower() and str(a).lower() in hay:
                        score += 4
                # explicit place from text
                guess = _entity_name_guess(intent.raw)
                for tok in [x for x in re.split(r"\s+", guess) if len(x) >= 3]:
                    if tok in hay:
                        score += 1
                candidates.append((score, e))
            if not candidates:
                return SkillResponse(text=f"Не нашёл датчик {'температуры' if kind=='temperature' else 'влажности'} в Home Assistant.")
            candidates.sort(key=lambda x: x[0], reverse=True)
            top = [e for s, e in candidates if s == candidates[0][0]][:3] if candidates[0][0] > 0 else [candidates[0][1]]
            lines = []
            for e in top:
                attrs = e.get("attributes") or {}
                fname = attrs.get("friendly_name") or e.get("entity_id")
                val = e.get("state")
                unit = attrs.get("unit_of_measurement") or ""
                lines.append(f"• {fname}: {val} {unit}".strip())
            return SkillResponse(text="Показания:\n" + "\n".join(lines), data={"entities": [e.get("entity_id") for e in top]})

        # what's on
        if "что включено" in t or "включенные" in t or "включённые" in t:
            states = self.ha.get_states()
            if not states.ok or not isinstance(states.data, list):
                return SkillResponse(text=f"Не удалось получить состояния: {states.error}")
            on = []
            for e in states.data:
                eid = str(e.get("entity_id", ""))
                if e.get("state") == "on" and eid.split(".")[0] in ("light", "switch", "fan", "media_player"):
                    fname = (e.get("attributes") or {}).get("friendly_name") or eid
                    on.append(str(fname))
            if not on:
                return SkillResponse(text="Сейчас нет включённых светильников/выключателей/медиа (по данным HA).")
            show = on[:20]
            more = f"\n… и ещё {len(on)-20}" if len(on) > 20 else ""
            return SkillResponse(text="Включено:\n• " + "\n• ".join(show) + more, data={"count": len(on)})

        # generic entity state by guess
        guess = _entity_name_guess(intent.raw)
        ent = self.ha.resolve_entity(guess) if guess else None
        if ent:
            attrs = ent.get("attributes") or {}
            fname = attrs.get("friendly_name") or ent.get("entity_id")
            state = ent.get("state")
            return SkillResponse(text=f"{fname}: {state}", data={"entity_id": ent.get("entity_id"), "state": state, "attributes": attrs})
        return SkillResponse(text="Уточните, какое устройство или датчик проверить (название/комнату).")

    def _resolve_room_media_player(self, room: Dict[str, Any], text: str) -> Optional[str]:
        mp = str(room.get("media_player") or "").strip()
        if mp:
            return mp
        # try by room name in HA entities
        name = str(room.get("name") or room.get("id") or "")
        ent = self.ha.resolve_entity(name, domains=MEDIA_DOMAINS)
        if ent:
            return str(ent.get("entity_id"))
        # generic: "колонка"/"динамик" + name guess
        guess = _entity_name_guess(text)
        ent = self.ha.resolve_entity(guess, domains=MEDIA_DOMAINS, prefer_room=name)
        if ent:
            return str(ent.get("entity_id"))
        return None

    def _handle_media(self, intent: IntentResult, ctx: DialogContext) -> SkillResponse:
        t = intent.raw.lower()
        room = self._current_room(intent, ctx)
        room_name = str(room.get("name") or room.get("id") or "комната")
        player = self._resolve_room_media_player(room, intent.raw)

        # volume
        if "громче" in t or "прибав" in t:
            if not player:
                return self._no_player(room_name)
            # step up
            self.ha.call_service("media_player", "volume_up", {"entity_id": player})
            return SkillResponse(text=f"Сделал громче в {room_name} ({player}).", data={"entity_id": player, "action": "volume_up"})
        if "тише" in t or "убав" in t or "уменьш" in t and "громк" in t:
            if not player:
                return self._no_player(room_name)
            self.ha.call_service("media_player", "volume_down", {"entity_id": player})
            return SkillResponse(text=f"Сделал тише в {room_name} ({player}).", data={"entity_id": player, "action": "volume_down"})
        mvol = re.search(r"громкост[ьи]\s*(?:на\s*)?(\d{1,3})", t)
        if mvol:
            if not player:
                return self._no_player(room_name)
            vol = max(0, min(100, int(mvol.group(1)))) / 100.0
            res = self.ha.call_service("media_player", "volume_set", {"entity_id": player, "volume_level": vol})
            if not res.ok:
                return SkillResponse(text=f"Не удалось установить громкость: {res.error}")
            return SkillResponse(text=f"Громкость в {room_name}: {int(vol*100)}%.", data={"entity_id": player, "volume": vol})

        # transport
        if "пауза" in t or ("останови" in t and ("музык" in t or "воспроизвед" in t or player)):
            if not player:
                return self._no_player(room_name)
            svc = "media_pause" if "пауза" in t else "media_stop"
            res = self.ha.call_service("media_player", svc, {"entity_id": player})
            if not res.ok:
                return SkillResponse(text=f"Не удалось выполнить команду медиа: {res.error}")
            return SkillResponse(text=f"{'Пауза' if svc=='media_pause' else 'Остановлено'} в {room_name} ({player}).", data={"entity_id": player, "action": svc})
        if "продолжи" in t or ("играй" in t and "музык" in t and not self._extract_play_query(t)):
            if not player:
                return self._no_player(room_name)
            res = self.ha.call_service("media_player", "media_play", {"entity_id": player})
            if not res.ok:
                return SkillResponse(text=f"Не удалось продолжить воспроизведение: {res.error}")
            return SkillResponse(text=f"Продолжаю воспроизведение в {room_name} ({player}).", data={"entity_id": player, "action": "media_play"})
        if "следующ" in t:
            if not player:
                return self._no_player(room_name)
            self.ha.call_service("media_player", "media_next_track", {"entity_id": player})
            return SkillResponse(text=f"Следующий трек в {room_name}.", data={"entity_id": player, "action": "next"})
        if "предыдущ" in t:
            if not player:
                return self._no_player(room_name)
            self.ha.call_service("media_player", "media_previous_track", {"entity_id": player})
            return SkillResponse(text=f"Предыдущий трек в {room_name}.", data={"entity_id": player, "action": "previous"})

        # play/request content
        if any(w in t for w in ["включи", "вруби", "запусти", "поставь", "играй", "воспроизведи"]) and any(w in t for w in ["музык", "песн", "трек", "плейлист", "радио", "альбом", "исполнител"]):
            if not player:
                return self._no_player(room_name)
            query = self._extract_play_query(intent.raw)
            if not query:
                # just resume/turn on player
                res = self.ha.call_service("media_player", "media_play", {"entity_id": player})
                if not res.ok:
                    # try turn_on
                    res = self.ha.call_service("media_player", "turn_on", {"entity_id": player})
                if res.ok:
                    return SkillResponse(text=f"Включаю воспроизведение в {room_name} ({player}).", data={"entity_id": player, "action": "play"})
                return SkillResponse(text=f"Не удалось включить воспроизведение в {room_name}: {res.error}", data={"entity_id": player})
            # Try best-effort: if query is URL -> play_media; else try common MA/service patterns are environment-specific,
            # so we attempt generic play_media music and also provide actionable guidance.
            if re.match(r"https?://", query):
                res = self.ha.call_service("media_player", "play_media", {
                    "entity_id": player,
                    "media_content_id": query,
                    "media_content_type": "music",
                })
                if res.ok:
                    return SkillResponse(text=f"Включаю по ссылке в {room_name} ({player}).", data={"entity_id": player, "query": query})
                return SkillResponse(text=f"Не удалось воспроизвести ссылку: {res.error}", data={"entity_id": player})
            # Try Music Assistant search/play via HA service if available (mass.play_media / music_assistant.play_media) - best effort
            # Different HA/MA versions expose different services; we try a few common ones.
            tried = []
            for domain, svc, payload in [
                ("mass", "play_media", {"media_id": query, "media_type": "track", "entity_id": player}),
                ("mass", "play_media", {"media_id": query, "media_type": "playlist", "entity_id": player}),
                ("music_assistant", "play_media", {"media_id": query, "media_type": "track", "entity_id": player}),
                ("media_player", "play_media", {"entity_id": player, "media_content_id": query, "media_content_type": "music"}),
            ]:
                tried.append(f"{domain}.{svc}")
                res = self.ha.call_service(domain, svc, payload)
                if res.ok:
                    return SkillResponse(text=f"Включаю «{query}» в {room_name} ({player}).", data={"entity_id": player, "query": query, "service": f"{domain}.{svc}"})
            return SkillResponse(text=(
                f"Команда принята: включить «{query}» в {room_name} ({player}), но прямое воспроизведение не подтвердилось через доступные сервисы HA. "
                "Для локальной музыки по комнатам рекомендуется Music Assistant в Home Assistant (локальная библиотека/радио) и привязка media_player к комнате в config.rooms. "
                "Можно также указать прямой URL потока/файла: «включи музыку https://... в этой комнате»."
            ), data={"entity_id": player, "query": query, "tried": tried})

        return SkillResponse(text=f"Уточните медиа-команду для {room_name}: пауза, продолжи, громче/тише, следующий трек, включи музыку/радио.")

    def _no_player(self, room_name: str) -> SkillResponse:
        return SkillResponse(text=(
            f"Для комнаты «{room_name}» не найден media_player. "
            "Укажите `media_player` (entity_id из Home Assistant) в `rooms` в config/config.local.json, "
            "либо назовите устройство явно."
        ), data={"room": room_name, "reason": "no_media_player"})

    @staticmethod
    def _extract_play_query(text: str) -> str:
        t = (text or "").strip()
        # try to capture after keywords
        m = re.search(r"(?:включи|вруби|запусти|поставь|играй|воспроизведи)\s+(?:музык[уаыеи]?|песн[юяи]?|трек|плейлист|радио|альбом)\s*(?:под названием|называется|:)?\s*(.+)$", t, re.I)
        if m:
            q = m.group(1).strip()
        else:
            m = re.search(r"(?:музык[уаыеи]?|песн[юяи]?|трек|плейлист|радио)\s+(.+)$", t, re.I)
            q = m.group(1).strip() if m else ""
        # strip room phrases
        q = re.sub(r"\b(в этой комнате|в комнате|здесь|тут|на колонк[еах]|на динамик[еах])\b.*$", "", q, flags=re.I).strip(" ,.-")
        q = re.sub(r"\s+", " ", q)
        # if too generic
        if q.lower() in ("", "музыку", "песню", "трек", "радио", "что-нибудь", "любую"):
            return ""
        return q

    def _handle_power(self, intent: IntentResult, ctx: DialogContext, action: str) -> SkillResponse:
        t = intent.raw.lower()
        room = self._current_room(intent, ctx)
        room_name = str(room.get("name") or "")
        guess = _entity_name_guess(intent.raw)

        # choose domains by keywords
        domains = None
        if any(w in t for w in ["свет", "ламп", "люстр"]):
            domains = LIGHT_DOMAINS
        elif any(w in t for w in ["штор", "жалюзи", "ворот", "рольстав"]):
            domains = COVER_DOMAINS
        elif any(w in t for w in ["сцен", "script", "скрипт", "автоматизац"]):
            domains = ["scene", "script"]
        elif any(w in t for w in ["розетк", "выключател", "switch", "вентилятор", "fan"]):
            domains = ["switch", "light", "fan", "input_boolean"]

        # If "весь свет в комнате" / generic in room
        if not guess or guess in ("свет", "лампу", "лампы", "все", "всё"):
            # try to find by room
            query = room_name or guess
        else:
            query = guess

        ent = self.ha.resolve_entity(query, domains=domains, prefer_room=room_name)
        if not ent and domains:
            # try without domain restriction
            ent = self.ha.resolve_entity(query, prefer_room=room_name)
        if not ent:
            # try room + keyword
            if room_name:
                ent = self.ha.resolve_entity(room_name, domains=domains or LIGHT_DOMAINS)
        if not ent:
            return SkillResponse(text=(
                f"Не нашёл подходящее устройство в Home Assistant для запроса «{intent.raw}». "
                "Уточните название сущности/устройства или комнату (как в HA)."
            ), data={"query": query, "room": room_name})

        eid = str(ent.get("entity_id"))
        domain = eid.split(".")[0]
        fname = (ent.get("attributes") or {}).get("friendly_name") or eid
        # map action/service
        if domain == "cover":
            svc = {"turn_on": "open_cover", "turn_off": "close_cover", "toggle": "stop_cover"}.get(action, "open_cover")
        elif domain == "lock":
            svc = {"turn_on": "unlock", "turn_off": "lock", "toggle": "lock"}.get(action, "lock")
        elif domain in ("scene",):
            svc = "turn_on"
        elif domain == "script":
            svc = "turn_on" if action != "turn_off" else "turn_off"
        else:
            svc = {"turn_on": "turn_on", "turn_off": "turn_off", "toggle": "toggle"}.get(action, "turn_on")

        res = self.ha.call_service(domain, svc, {"entity_id": eid})
        if not res.ok:
            return SkillResponse(text=f"Не удалось выполнить {domain}.{svc} для {fname}: {res.error}", data={"entity_id": eid, "error": res.error})
        verb = {"turn_on": "Включаю", "turn_off": "Выключаю", "toggle": "Переключаю"}.get(action, "Выполняю")
        return SkillResponse(text=f"{verb}: {fname} ({eid}).", data={"entity_id": eid, "service": f"{domain}.{svc}", "friendly_name": fname})
