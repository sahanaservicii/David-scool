# Свободный Голос (FreeVoice Assistant)

Локальный, переносимый голосовой помощник без подписок: **оффлайн-first**, с поддержкой Home Assistant, мультирум-контекста (комнаты), веб-интерфейсом, CLI и Android-клиентом.

Проект вдохновлён сильными сторонами Алисы, Siri, Google Assistant и Salute (см. `docs/COMPARISON.md`) и реализует их как открытый, модульный и приватный каркас под свой дом/сервер.

## Ключевые возможности

- **Диалог:** команды и свободный чат (при подключении локальной LLM, OpenAI-compatible: Ollama/llama.cpp и др.) — без облачных подписок.
- **Умный дом (Home Assistant):** статус, датчики, включение/выключение устройств, управление медиа-плеерами по комнатам (через REST API HA).
- **Мультирум-контекст:** комнаты в конфиге (`rooms[]`), выбор комнаты в UI/API, команды «в этой комнате» и маршрутизация музыки на `media_player` комнаты.
- **Голос и текст:** Web UI (микрофон/озвучка через Web Speech API браузера, push-to-talk) + CLI; Android WebView APK-клиент.
- **Локальные навыки:** время/дата, калькулятор, заметки, таймеры, статус системы, справка.
- **Поиск/погода (опционально, без ключей):** DuckDuckGo HTML / SearXNG, wttr.in — при наличии сети.
- **Интеграции:** мост к `homelab.py` (если доступен в окружении).

> Для режима «микрофон и колонка в каждой комнате, всегда слушает и общается как в чате» нужны спутники (wake-word/STT/TTS) и выделенный сервер — см. **`docs/MULTIROOM_HA.md`** (архитектура, железо, ПО, пошаговый план).

## Быстрый старт

```bash
cd /root/workspace/voice-assistant

# Проверка
python3 main.py --status
python3 -m unittest discover -s tests -v

# CLI
python3 main.py "который час"
python3 main.py "посчитай (12+8)/4"
python3 main.py

# Веб-интерфейс
python3 main.py --web
# или: ./scripts/run_web.sh
# открыть http://127.0.0.1:8765 (или LAN IP при allow_lan)
```

## Конфигурация

- База: `config/config.json`
- Локальные/продакшен переопределения: `config/config.local.json` (не коммитить с секретами)
- Пример: `config/config.local.example.json`
- Env: `ASSISTANT_HOST`, `ASSISTANT_PORT`, `ASSISTANT_LANG`, `ASSISTANT_LOG_LEVEL`, `HASS_URL`, `HASS_TOKEN`, `LLM_BASE_URL`, `LLM_MODEL`

Минимальный пример для сервера с Home Assistant, локальной LLM и комнатами:

```json
{
  "server": { "host": "0.0.0.0", "port": 8765, "allow_lan": true, "api_token": "CHANGE_ME" },
  "home_assistant": { "url": "http://homeassistant.local:8123", "secrets_file": "~/.config/opencode/secrets/homelab.env" },
  "llm": { "provider": "auto", "openai_compat": { "base_url": "http://127.0.0.1:11434/v1", "model": "qwen2.5:7b-instruct" } },
  "rooms": [
    { "id": "kitchen", "name": "Кухня", "aliases": ["кухне"], "media_player": "media_player.kitchen" },
    { "id": "living_room", "name": "Гостиная", "aliases": ["гостиной"], "media_player": "media_player.living_room" }
  ]
}
```

## Android APK (клиент)

Готовый debug APK (WebView-клиент к серверу FreeVoice): `dist/FreeVoice-debug.apk` (копия: `/root/workspace/FreeVoice-debug.apk`).
- Пакет: `com.freevoice.assistant`, v0.1.0, minSdk 24, targetSdk 34
- Разрешения: INTERNET, RECORD_AUDIO, MODIFY_AUDIO_SETTINGS, ACCESS_NETWORK_STATE (cleartext для локальных http-адресов включён)
- Исходники и ручная сборка: `android-app/` (`build-manual-apk.sh`)
- Использование: запустите сервер `python3 main.py --web --host 0.0.0.0 --port 8765`, установите APK, укажите адрес сервера (LAN IP), разрешите микрофон.
- Ограничение: APK — клиент к серверу; автономность/голос зависят от сервера и WebView устройства.

## API (основное)

- `GET /api/status` — состояние, версии, навыки, HA/LLM, комнаты
- `GET /api/health` — краткий health-check
- `GET /api/rooms` — список комнат
- `POST /api/chat` — `{ "text": "...", "session_id": "web", "room": "kitchen" }` → ответ `{ text, speak, intent, skill, data, room, ... }`

## Структура проекта

```
voice-assistant/
  main.py                 # точка входа (CLI/--web)
  config/                 # config.json, config.local.example.json
  assistant/
    core/                 # движок, конфиг, контекст, хранилище
    nlu/                  # intents/entities (правила, расширяемо)
    skills/               # навыки (time, notes, timer, ha, search, ...)
    integrations/         # Home Assistant client
    tts/, stt/            # абстракции синтеза/распознавания речи
    search/               # поиск без подписки (DDG/SearXNG)
    llm/                  # точка расширения под LLM
    web/                  # HTTP API + статический UI
    cli.py                # CLI интерфейс
  docs/                   # архитектура, деплой, мультирум+HA, навыки, сравнение
  deploy/                 # systemd и примеры развёртывания
  scripts/                # удобные скрипты запуска
  tests/                  # тесты
  android-app/            # Android WebView-клиент (APK)
  dist/                   # готовые артефакты (APK)
  data/                   # локальные данные (SQLite), создаётся автоматически
```

## Документация

- **`docs/MULTIROOM_HA.md`** — главный гайд: локальный мультирум-ассистент, Home Assistant, спутники (микрофоны/колонки), музыка по комнатам, требования к серверу/ОС/железу и пошаговый план.
- `docs/DEPLOYMENT.md` — развёртывание, офлайн/онлайн, продакшен-чеклист.
- `docs/ARCHITECTURE.md` — архитектура и точки расширения.
- `docs/SKILLS.md` — навыки и расширение.
- `docs/COMPARISON.md` — сравнение с Алиса/Siri/Google Assistant/Salute.
- `SECURITY.md` — модель безопасности и рекомендации.

## Лицензия

MIT — см. `LICENSE`.
