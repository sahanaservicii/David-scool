# Развёртывание и продакшен (FreeVoice)

## 1. Быстрый запуск (локально/тест)

```bash
cd /root/workspace/voice-assistant
python3 -m unittest discover -s tests -v
python3 main.py --status
python3 main.py --web --host 127.0.0.1 --port 8765
# Web UI: http://127.0.0.1:8765
```

API:
- `GET /api/health` — быстрый health-check
- `GET /api/status` — статус (HA quick-probe по умолчанию; `?quick=0` для полного)
- `GET /api/rooms` — комнаты
- `POST /api/chat` — `{text, session_id?, room?}`

## 2. Конфигурация для продакшена

1. Скопируйте пример: `config/config.local.example.json` → `config/config.local.json`
2. Настройте:
   - **Сервер/LAN:** `server.host="0.0.0.0"`, `server.allow_lan=true`, уникальный `server.api_token`
   - **Home Assistant:** `home_assistant.url` и токен (`HASS_TOKEN` в env/secrets или `home_assistant.token` в локальном конфиге). HA URL также может быть обнаружен из `../homelab/homelab.json`, если доступен.
   - **LLM (локальный чат):** `llm.provider="auto"` и `llm.openai_compat.base_url` на локальный OpenAI-compatible сервер (Ollama/llama.cpp). Без LLM работают навыки/команды, но не свободный диалог.
   - **Комнаты/мультирум:** `rooms[]` с `id`, `name`, `aliases`, `media_player` (entity_id HA)
   - **Безопасность:** `security.log_conversations=false`, не хранить секреты в git

Переменные окружения: `ASSISTANT_HOST/PORT/LANG/LOG_LEVEL`, `HASS_URL`, `HASS_TOKEN`, `HOMELAB_SECRETS_FILE`, `LLM_BASE_URL`, `LLM_MODEL`, `LLM_API_KEY`.

## 3. Запуск как сервис (systemd)

Пример: `deploy/freevoice.service` (адаптируйте пути/пользователя).

```bash
sudo useradd --system --home /opt/freevoice --shell /usr/sbin/nologin freevoice || true
sudo mkdir -p /opt/freevoice
sudo rsync -a /path/to/voice-assistant/ /opt/freevoice/
sudo chown -R freevoice:freevoice /opt/freevoice/data /opt/freevoice/logs 2>/dev/null || true
sudo cp /opt/freevoice/deploy/freevoice.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now freevoice
sudo systemctl status freevoice
```

Логи: `journalctl -u freevoice -f`

## 4. Режимы работы

### Полностью локально (рекомендовано для продакшена)
- **Навыки/умный дом:** работают в LAN при доступном Home Assistant.
- **LLM:** локальный сервер (Ollama `:11434/v1`, llama.cpp `:8080/v1` и т.п.) — без интернета и подписок.
- **STT/TTS:** для браузера — Web Speech API (зависит от устройства/движка). Для гарантированно локального серверного STT/TTS — Piper + faster-whisper/whisper.cpp/Vosk + спутники/Wyoming (см. `docs/MULTIROOM_HA.md`).
- **Поиск/погода:** можно отключить (`search.allow_online=false`) для полной приватности; либо использовать локальный SearXNG.

### Офлайн без локальной LLM
- Работают: время, калькулятор, заметки, таймеры, система, HA-команды (если HA в LAN), справка, базовый диалог.
- Свободный чат ограничен (fallback подскажет подключить LLM).

### Онлайн без подписок (опционально)
- Поиск: DuckDuckGo HTML / свой SearXNG, без API-ключей.
- Погода: открытый источник wttr.in (best-effort).
- Учитывайте приватность запросов к сторонним сервисам.

## 5. Home Assistant

- Нужен долгоживущий токен доступа HA.
- FreeVoice обращается к HA по REST API (`/api/...`) для состояний и вызова сервисов.
- Для медиа по комнатам укажите `rooms[].media_player` (entity_id). Рекомендуется Music Assistant в HA для локальной музыки/радио.
- При недоступности HA навыки возвращают понятную ошибку (без падения сервера).

## 6. Мультирум (микрофоны/колонки в комнатах)

Web UI/APK — удобный клиент (push-to-talk). Для «всегда слушающих» спутников и воспроизведения TTS в комнатах требуется голосовой стек (wake-word, STT, TTS, аудио I/O) на спутниках/сервере.

Подробная архитектура, выбор железа/ОС, ПО (HA, Wyoming/ESPHome satellites, Piper, faster-whisper, Ollama, Music Assistant) и пошаговый план: **`docs/MULTIROOM_HA.md`**.

## 7. Продакшен-чеклист

- [ ] `config/config.local.json` настроен; секреты только в env/защищённых файлах, не в git
- [ ] `server.api_token` задан при `allow_lan=true`; доступ ограничен LAN/firewall
- [ ] HA URL/токен проверены (`/api/status`, команда «статус HA»)
- [ ] LLM endpoint проверен (если нужен свободный диалог)
- [ ] `rooms[]` и `media_player` привязаны к реальным сущностям HA
- [ ] Сервис под systemd/supervisor, автозапуск и рестарт
- [ ] Бэкап `data/assistant.db` (заметки/таймеры/история по настройке)
- [ ] Тесты пройдены: `python3 -m unittest discover -s tests -v`
- [ ] Для голосовых спутников — выбран и развёрнут STT/TTS/wake-word стек (см. мультирум-гайд)

## 8. Известные ограничения текущего окружения

- В некоторых окружениях отсутствуют предустановленные модели STT/TTS/LLM — их нужно развернуть на целевом сервере.
- Голос в браузере (Web Speech API) зависит от платформы: TTS часто локальный, STT может требовать сеть (зависит от браузера/ОС).
- Полный мультирум «always-listening» не реализуется только Web UI — нужны аппаратные/программные спутники.
