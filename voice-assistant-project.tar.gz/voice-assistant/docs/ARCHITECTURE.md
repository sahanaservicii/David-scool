# Архитектура FreeVoice

## Цели
- **Офлайн-first, без подписок**: базовые функции и управление домом в локальной сети.
- **Модульность**: заменяемые STT/TTS/NLU/LLM/Search/Skills/Integrations.
- **Переносимость**: ядро на Python stdlib, конфиг JSON, SQLite, минимум зависимостей.
- **Безопасность**: локальные данные, ограничение опасных действий, явная настройка LAN-доступа.

## Компоненты

```
[ Клиенты ]  Web UI (браузер, push-to-talk STT/TTS) | Android WebView APK | CLI | (будущие) voice satellites
   │  HTTP /api/chat {text, session_id, room}
   ▼
[ Web/API ]  assistant.web.server  (ThreadingHTTPServer, лимиты, опц. token, /api/health|status|rooms|chat)
   │
   ▼
[ Engine ]  assistant.core.engine.AssistantEngine
   │  ├─ Config (config.json + config.local.json + env)
   │  ├─ Storage (SQLite: notes, timers, history, kv)
   │  ├─ DialogContext (сессии, слоты, room)
   │  ├─ IntentRouter (NLU: правила/паттерны → intent + entities)
   │  ├─ SkillRegistry → Skill.handle()
   │  ├─ Integrations: HomeAssistantClient (REST)
   │  └─ TTS/STT providers (абстракции)
   │
   ├──> [ Skills ] smalltalk, help, time, calc, notes, timer, system,
   │               search, weather, web, app_control, homelab, ha (Home Assistant + media/rooms), fallback(chat)
   │
   └──> [ Fallback ] local LLM (OpenAI-compatible) → search → подсказка
   │
   ▼
[ Response ] { text, speak, intent, skill, confidence, entities, data, room, session_id }
```

## Поток обработки
1. Клиент отправляет текст (из браузерного STT, ввода или спутника) и опционально `room`.
2. `Engine.process()` фиксирует комнату в контексте, сохраняет сообщение, проверяет таймеры.
3. `IntentRouter.route()` определяет intent/skill/entities.
4. `SkillRegistry.dispatch()` вызывает навык. Навык может использовать `storage`, `ha` клиент, конфиг комнат.
5. Если навык не найден — `fallback`: локальная LLM (если настроена) или поиск/подсказка.
6. Ответ возвращается клиенту; клиент озвучивает `speak` (браузер TTS) или воспроизводит серверный TTS (в целевой мультирум-архитектуре).

## Мультирум и Home Assistant
- `rooms[]` в конфиге: маппинг комнаты → `media_player` entity и метаданные спутника.
- `HomeAssistantClient`: URL/токен из config/env/secrets (без вывода секретов), быстрый `safe_status(quick)`, состояния, вызов сервисов, резолв сущностей по имени/комнате.
- Навык `ha`: запросы датчиков, управление устройствами, медиа-команды (transport/volume/play_media best-effort, в т.ч. попытки MA-сервисов) с учётом комнаты.
- Целевая always-listening архитектура (Wyoming/ESPHome satellites, Piper, faster-whisper, Music Assistant) описана в `docs/MULTIROOM_HA.md`.

## Данные и конфиг
- `data/assistant.db` — SQLite (заметки, таймеры, напоминания, kv, история опционально).
- `config/config.json` + `config/config.local.json` (deep merge) + env overrides.
- Секреты: `HASS_TOKEN`, LLM API key и т.п. — в env/защищённых файлах (например `~/.config/opencode/secrets/homelab.env`), не в git.

## Расширение
- **Навык:** класс `Skill` в `assistant/skills/`, правило в `assistant/nlu/router.py`, регистрация в `engine._register_skills()`.
- **Интеграция:** модуль в `assistant/integrations/`, использование из навыков/движка.
- **Провайдеры STT/TTS/LLM/Search:** абстракции в соответствующих пакетах, выбор через конфиг.
- **Мультирум:** добавить комнаты/устройства в `rooms[]`, связать с HA entity_id; подключить спутники к API/voice pipeline.

## Безопасность
- AST-калькулятор (без `eval`), allowlist для запуска приложений, фиксированные аргументы homelab-моста.
- Защита от path traversal в static server, лимиты тела/текста запроса.
- Сервер по умолчанию `127.0.0.1`; LAN — явный `allow_lan`, опциональный `api_token`.
- Подробности: `SECURITY.md`.
