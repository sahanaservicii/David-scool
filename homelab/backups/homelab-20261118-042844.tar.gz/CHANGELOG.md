# Журнал изменений

## 2026-11-15 — создан агент «Домовой»

Добавлено:

- Главный агент `domovoy` и подагенты: `network`, `home`, `android`,
  `security`, `backup`, `docs`.
- Навыки: `homelab`, `openwrt-admin`, `home-assistant-local`, `android-local`,
  `ip-cameras`.
- Офлайн-инструмент `/root/workspace/homelab/homelab.py` (stdlib): doctor,
  scan, inventory, HA REST, OpenWrt SSH, Android ADB, камеры, бэкапы, отчёты.
- Инвентарь `homelab.json`, `INVENTORY.md`, этот журнал, `RUNBOOK.md`.
- `default_agent: domovoy` в `~/.config/opencode/opencode.json`.

Откат:

- Убрать `default_agent` из `opencode.json` (или вернуть `build`).
- Удалить `~/.config/opencode/agents/*.md` и новые навыки, если не нужны.
- Инструменты и данные — в `/root/workspace/homelab/`, удаляются отдельно.

## 2026-11-15 — сетевой аудит (по отчёту)

- Закрыт ADB `:5555` на Android TV `192.168.1.139` (`persist.adb.tcp.port=-1`,
  `service.adb.tcp.port=-1`, перезапуск `adbd`). Откат: включить отладку по сети
  в настройках разработчика.
- Удалён мёртвый DNAT `8123 → .156` и дубль правила WireGuard, firewall
  перезагружен. Откат: вернуть правила из `firewall-backup.json` осознанно.
- Камеры XM/NVR: HTTP без TLS, требуется смена паролей/изоляция. Не менялось.

## 2026-11-15 — HA отложен, подготовлен доступ по SSH

- `home_assistant.enabled=false` в `homelab.json`; `doctor` пропускает HA
  (`[--] отложено`), остальные проверки работают.
- `doctor` показывает локальный IP маршрута к `192.168.1.1` — помогает понять,
  активен ли Wi-Fi/WireGuard.
- Сгенерирован ключ `~/.ssh/id_ed25519` (`domovoy@phone`). Публичную часть
  нужно добавить в `/etc/dropbear/authorized_keys` на OpenWrt.
- Включение HA позже: `"enabled": true` и `HASS_TOKEN` в secrets.

## 2026-11-17 — DNAT Home Assistant на WAN:18443 для телефона

По явному подтверждению пользователя на OpenWrt добавлен проброс WAN TCP
`18443 → 192.168.1.156:8123` (Home Assistant). Имена: redirect `HA-phone-only`,
rule `HA-phone-only-allow`; добавлен forwarding `wan → lan`. Доступ ограничен
источником `91.79.32.179/32` — публичный IP, с которого приходят подключения
и который виден как endpoint WireGuard-пира.

Добавлено:

- DNAT и rule в `/etc/config/firewall`, forwarding `wan → lan`.
- `fw4 check` прошёл, firewall перезагружен; SSH и роутер остались доступны.
- В `homelab.json` `home_assistant.enabled` уже `true` (запись от 15.11 об
  «отложенном» HA тем самым устарела).

Проверка:

- TCP `sahanovschi.v6.rocks:18443` открыт.
- `GET /` → 200 с заголовком Home Assistant; `GET /api/` → 401.
- `conntrack`: `src=91.79.32.179 dst=172.25.213.7 dport=18443 → 192.168.1.156:8123`.

Бэкапы перед правкой:

- `/root/workspace/homelab/backups/openwrt-20261117-052939.tar.gz`
- `/root/workspace/homelab/backups/homelab-20261117-052939.tar.gz`
- на роутере: `/root/firewall.bak.ha-1794893394`

Откат:

- Удалить redirect `HA-phone-only`, rule `HA-phone-only-allow` и forwarding
  `wan → lan`, затем `fw4 check && /etc/init.d/firewall reload`.
- Или вернуть `/etc/config/firewall` из `/root/firewall.bak.ha-1794893394`
  (либо из бэкапа выше) и перезагрузить firewall. SSH/WireGuard при этом
  остаются доступны.

Риски (отдельно):

- Трафик идёт по HTTP без TLS.
- Whitelist привязан к `91.79.32.179/32`: при смене публичного IP телефона
  доступ пропадёт, правило нужно обновить.
- WireGuard остаётся предпочтительным каналом; DNAT — запасной путь только
  для этого IP.

## 2026-11-17 — Пространство Home Assistant: 2 дома и комнаты

Через WebSocket API HA (минимальный клиент на stdlib, `/tmp/opencode/ha_ws.py`)
создано 2 Floor и 13 Area. Device/entity-реестры не менялись: 27 устройств с
`area_id` остались на месте и автоматически оказались в доме
`raxmaninova-49`; 194 из 221 устройства без зоны намеренно не трогались.

Добавлено:

- Floors: `raxmaninova-49` (`raxmaninova_49`), `izmailovo-47`
  (`izmailovo_47`).
- 7 прежних Area перенесены в `raxmaninova-49`: Гостиная (49) `[gostinaia]`,
  Кухня (49) `[kukhnia]`, Обородования `[oborodovaniia]`, Спальня (49)
  `[spalnia]`, Электра шиток `[elektra_shitok]`, Улица (49) `[ulitsa]`,
  Квартира `[kvartira]`. Четыре имени получили суффикс `(49)`: HA требует
  уникальности имён Area.
- 6 новых Area для `izmailovo-47`: Ванная `[vannaia]`, Коридор `[koridor]`,
  Гостиная `[gostinaia_2]`, Кухня `[kukhnia_2]`, Спальня `[spalnia_2]`,
  Улица `[ulitsa_2]`.

Проверка (2026-11-17, повторный `.../list`): 2 Floor и 13 Area с нужными
`floor_id`, имена совпадают с описанными выше.

Бэкап реестров до изменений:
`/root/workspace/homelab/backups/ha-registries-20261117.jsonl` (4 строки:
floors 0, areas 7, devices 221, entities 833).

Откат:

- вернуть 7 Area прежние имена (без `(49)`) и `floor_id: null` через
  `config/area_registry/update`; удалить 6 новых Area и оба Floor командами
  `config/area_registry/delete` / `config/floor_registry/delete` (сначала Area,
  затем Floors) — всё через тот же WS-клиент;
- device/entity-реестры откатывать не нужно, они не менялись; полный снимок —
  в бэкапе выше. Подробности и команды — в `RUNBOOK.md`, раздел 9.
